<?php

require_once("./Stack.php");
require_once("./StackNode.php");

class SuffixReplacementGrammarCaseTestCase
{
    private $route; /** @var splStack current route */
    private $rules; /** @var array array of rules */
    private $marked; /** @var array which rules have been explored */
    private $N; /** @var int number of rules */
    private $start; /** @var string starting point string */
    private $goal; /** @var string desired goal string */


    public function __construct($numberOrRules, $start, $goal)
    {
        $this->N = $numberOrRules;
        $this->start = $start;
        $this->goal = $goal;
        $this->rules = array();
    }

    public function addRule($rule)
    {
        $this->rules[] = $rule;
    }


    public function tryToReachGoal()
    {
        $smallestDistance = INF;

        $currentString = $this->start;

        $this->route = new Stack();
        $this->marked = array();

        $this->route->push($currentString);

        while (!$this->route->isEmpty()) {
            $currentString = $this->route->pop();
            foreach ($this->rules as $index => $rule) {
                if ($rule->canTransform($currentString)) {
                    $newString = $rule->transform($currentString);
                    if (!isset($this->marked[$newString])) {
                        if ($newString == $this->goal) {
                            $distance = count($this->route);
                            if ($distance < $smallestDistance) {
                                $smallestDistance = $distance;
                            }
                        } else {
                            $this->route->push($newString);
                            $this->marked[$newString] = true;
                        }
                    }
                }
            }
        }

        return $smallestDistance;
    }


}


class Rule
{
    private $suffix;
    private $replacemnetSuffix;
    private $length;


    public function __construct($suffix, $replacementSuffix)
    {
        if (strlen($suffix) != strlen($replacementSuffix)) {
            throw new \InvalidArgumentException("suffix and replacement must be of the same length");
        }
        $this->suffix = $suffix;
        $this->replacemnetSuffix = $replacementSuffix;

        $this->length = strlen($suffix);
    }

    public function canTransform($string)
    {
        if (substr($string, -$this->length) == $this->suffix) {
            return true;
        } else {
            return false;
        }

    }


    public function transform($string)
    {
        if (!$this->canTransform($string)) {
            throw new \InvalidArgumentException("this string does not have a valid suffix to change");
        }

        $result = substr_replace($string, $this->replacemnetSuffix, -$this->length);
        return $result;
    }

    public function reverseTransform($string)
    {
        $result = substr_replace($string, $this->suffix, -$this->length);
        return $result;
    }

}


function setupAndRun($filename)
{
    $handle = fopen($filename, "r");

    $project = array();
    $tempTestCase = null;
    $numberOfTestCases = 0;

    if ($handle) {
        while (($line = fgets($handle)) !== false) {
            $line = str_replace("\n", "", $line);
            $line = rtrim($line);

            if ($line == ".") {
                break;
            }

            $pieces = preg_split('/\s+/', $line);

            if (ctype_digit($pieces[count($pieces) - 1]) == true) {
                $start = $pieces[0];
                $goal = $pieces[1];
                $numberOrRules = $pieces[2];
                $tempTestCase = new SuffixReplacementGrammarCaseTestCase($numberOrRules, $start, $goal);
                $numberOfTestCases++;
                $project[$numberOfTestCases] = $tempTestCase;
            } else {
                $suffix = $pieces[0];
                $replacementSuffix = $pieces[1];
                $rule = new Rule($suffix, $replacementSuffix);
                $project[$numberOfTestCases]->addRule($rule);
            }

        }
    } else {
        // error opening the file.
        "no file exists";
    }

    $count = 1;
    foreach ($project as $testCase) {
        $dist = $testCase->tryToReachGoal();

        // add in 1 to account for starting point
        $distanceDisplay = ($dist != INF)? $dist + 1 : "No Solution";


        echo "Case " . $count . ": " . $distanceDisplay . "<br/>";
    }

}


setupAndRun("suffixRules.txt");